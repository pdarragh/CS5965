{-
    CleanUp

    The phase at the end of each turn.
-}

module Dominion.Player.CleanUp where

import Dominion.State

doCleanUp :: State -> String
doCleanUp state = "clean up"
