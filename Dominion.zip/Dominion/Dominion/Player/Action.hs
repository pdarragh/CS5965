{-
    Action

    The phase of the turn devoted to doing things.
-}

module Dominion.Player.Action where

import Dominion.State

takeAction :: State -> String
takeAction state = "action"
