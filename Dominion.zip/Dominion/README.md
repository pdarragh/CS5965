# Dominion

## Purpose

This project is supposd to provide an automated player for a Dominion game according to the protocol found in PROTOCOL.md
